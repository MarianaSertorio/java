
package entidade;

/**
 *
 * @author SERTORIO
 */
public class Maquiagem {

    public Maquiagem() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    /**
     * @return the idMaquiagem
     */
    public int getIdMaquiagem() {
        return idMaquiagem;
    }

    /**
     * @param idMaquiagem the idMaquiagem to set
     */
    public void setIdMaquiagem(int idMaquiagem) {
        this.idMaquiagem = idMaquiagem;
    }

    /**
     * @return the nomeMaquiagem
     */
    public String getNomeMaquiagem() {
        return nomeMaquiagem;
    }

    /**
     * @param nomeMaquiagem the nomeMaquiagem to set
     */
    public void setNomeMaquiagem(String nomeMaquiagem) {
        this.nomeMaquiagem = nomeMaquiagem;
    }

    /**
     * @return the descricao
     */
    public String getDescricao() {
        return descricao;
    }

    /**
     * @param descricao the descricao to set
     */
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    /**
     * @return the valor
     */
    public Double getValor() {
        return valor;
    }

    /**
     * @param valor the valor to set
     */
    public void setValor(Double valor) {
        this.valor = valor;
    }
    
   public int idMaquiagem;
   public String nomeMaquiagem;
   public String descricao;
   public Double valor;
   
   public Maquiagem(int idMaquiagem, String nomeMaquiagem,String descricao,
             Double valor){
        this.idMaquiagem = idMaquiagem;
        this.nomeMaquiagem= nomeMaquiagem;
        this.descricao = descricao;
        this.valor = valor;
    }
   
}
