
package dao;

import entidade.Usuario;
import conexao.Conexao;
import java.sql.*;
import javax.swing.*;

public class UsuarioDao {
   Connection conexao = null;
   PreparedStatement stmt = null;
   ResultSet rs = null;
   
   public UsuarioDao(){
       this.conexao = Conexao.conexao();
   }
   
   public void adicionar(Usuario usuario){
       String sql = "insert into usuario"
               + "(nome,email,senha,confirmarSenha) values"
               + "(?,?,?,?)";
       try{
           stmt = conexao.prepareStatement(sql);
           stmt.setString(1, usuario.getNome());
           stmt.setString(2, usuario.getEmail());
           stmt.setString(3, usuario.getSenha());
           stmt.setString(4, usuario.getConfirmarSenha());
           stmt.executeUpdate();
       }catch(Exception e){
           JOptionPane.showMessageDialog
        (null,"Erro no sql"+ e.getMessage());
       }
   }
   
   public boolean email(String email,String senha){
       boolean existe = false;
       String sql = "select email,senha from usuario "
               + "where email = ? and senha = ?";
       try{
           stmt = this.conexao.prepareStatement(sql);
           stmt.setString(1, email);
           stmt.setString(2, senha);
           rs = stmt.executeQuery();
           while(rs.next()){
              existe = true; 
           }
       }catch(Exception e){
           JOptionPane.showMessageDialog
        (null, "Problema ao consultar login"+e.getMessage());
       }
       return existe;
   }
}
