package dao;

import conexao.Conexao;
import java.sql.*;
import javax.swing.*;
import entidade.*;
import java.util.ArrayList;
import java.util.List;

public class AgendamentoDao {

    Connection conexao = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    public AgendamentoDao() {
        this.conexao = Conexao.conexao();
    }

    public void adicionar(Agendamento agendamento) {
        String sql = "insert into agendamento "
                + "(dataAgendamento,observacao,valor,hora,idCliente,idMaquiagem) "
                + "values (?,?,?,?,?,?)";
        try {
            stmt = conexao.prepareStatement(sql);
            stmt.setString(1, agendamento.getDataAgendamento());
            stmt.setString(2, agendamento.getObservacao());
            stmt.setDouble(3, agendamento.getValor());
            stmt.setString(4, agendamento.getHora());
            stmt.setInt(5, agendamento.getCliente().getIdCliente());
            stmt.setInt(6, agendamento.getMaquiagem().getIdMaquiagem());
            stmt.executeUpdate();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro no banco" + e.getMessage());
        }
    }

    public void atualizar(Agendamento agendamento) {

        try {

            stmt = conexao.prepareStatement("UPDATE agendamento set dataAgendamento = ?, observacao = ?, "
                    + " valor = ?, hora=?"
                    + "where idAgendamento = ?");

            stmt.setString(1, agendamento.getDataAgendamento());
            stmt.setString(2, agendamento.getObservacao());
            stmt.setDouble(3, agendamento.getValor());
            stmt.setString(4, agendamento.getHora());
            stmt.setInt(5, agendamento.getIdAgendamento());

            stmt.executeUpdate();
            stmt.close();

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(null, "Erro no DAO" + ex);
        }
    }
    public boolean excluir (String idAgendamento){
        try{
            stmt = conexao.prepareStatement("Delete from agendamento where idAgendamento= ?");
            stmt.setString(1, idAgendamento);
            stmt.executeUpdate();
            return true;
        }catch(Exception e){
            return false;
        }
    }

    public List<Agendamento> listar(String data) {
        List<Agendamento> lista = new ArrayList();
        String sql = "SELECT * from agendamento INNER JOIN cliente"
                + " INNER JOIN maquiagem ON agendamento.idCliente = cliente.idCliente "
                + "and agendamento.idMaquiagem = maquiagem.idMaquiagem"
                + "where dataAgendamento like ? order by idAgendamento;";
        try {
            stmt = conexao.prepareStatement(sql);
            stmt.setString(1, "%" + data + "%");
            rs = stmt.executeQuery();
            while (rs.next()) {
                Agendamento agendamento = new Agendamento();
                Cliente cliente = new Cliente();
                Maquiagem maquiagem = new Maquiagem();
                
                agendamento.setCliente(cliente);
                agendamento.setMaquiagem(maquiagem);
                agendamento.setIdAgendamento(rs.getInt("idAgendamento"));
                agendamento.setDataAgendamento(rs.getString("dataAgendamento"));
                agendamento.setObservacao(rs.getString("observacao"));
                agendamento.setValor(rs.getDouble("valor"));
                agendamento.setHora(rs.getString("hora"));
                cliente.setNomeCliente(rs.getString("nomeCliente"));
                maquiagem.setNomeMaquiagem(rs.getString("nomeMaquiagem"));

                lista.add(agendamento);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro na consulta" + e.getMessage());
        }
        return lista;
    }
}
