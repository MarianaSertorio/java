package telas;

import dao.*;
import entidade.*;
import conexao.Conexao;
import java.sql.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ConsulAgendamento extends javax.swing.JFrame {
    
    Connection conexao = null;
    PreparedStatement linguagem = null;
    ResultSet linha = null;

    public ConsulAgendamento() {
        initComponents();
      conexao = Conexao.conexao();        
    }
    void limpar(){
        jdataAgendamento.setText("");
        jobservacao.setText("");
        jvalor.setText("");
        jcliente.setText("");
        jmaquiagem.setText("");
        jhora.setText("");
        jdataAgendamento.requestFocus();
    }
    void novo(){
        jdataAgendamento.setEnabled(true);
        jobservacao.setEnabled(true);
        jvalor.setEnabled(true);
        jcliente.setEnabled(true);
        jmaquiagem.setEnabled(true);
        jeditar.setEnabled(true);
        jexcluir.setEnabled(true);
        jdataAgendamento.requestFocus();
    }
   
    
    void consultar(){
        novo();
        try{
            String dataAgendamento = jdataConsulta.getText();
            AgendamentoDao dao = new AgendamentoDao();
            List<Agendamento> agendamentos = dao.listar(dataAgendamento);
            
            Agendamento agendamento = new Agendamento();
            Cliente c = new Cliente();
            agendamento.setCliente(c); //chave estrangeira
            Maquiagem m = new Maquiagem();
            agendamento.setMaquiagem(m);
            
            DefaultTableModel model = (DefaultTableModel) jtabela.getModel();
            model.setNumRows(0);
            
            for(Agendamento a : agendamentos){
                model.addRow(new Object[]{
                    a.getIdAgendamento(),
                    a.getDataAgendamento(),
                    a.getHora(),
                    a.getCliente().getNomeCliente(),
                    a.getMaquiagem().getNomeMaquiagem(),
                    a.getObservacao(),
                    "R$ "+a.getValor()
                });
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog
        (null,"Erro na consulta"+ e.getMessage());
        }
    }
     void editar(){

        String dataAgendamento = jdataAgendamento.getText();
        String hora = jhora.getText();
        String observacao = jobservacao.getText();
        double valor = Double.parseDouble(jvalor.getText().replace("R$", "").replace(',','.')); 
        

        Agendamento ag = new Agendamento();

        ag.setDataAgendamento (dataAgendamento);
        ag.setHora (hora);
        ag.setObservacao (observacao);
        ag.setValor (valor);

        AgendamentoDao dao = new AgendamentoDao();
        dao.atualizar( 
                ag);
        JOptionPane.showMessageDialog(null, "Agendamento Atualizado");
        limpar ();
        }
     void excluir(){
        AgendamentoDao dao = new AgendamentoDao();
        int confirma = JOptionPane.showConfirmDialog
        (null, "Deseja Excluir?","Mensagem",JOptionPane.YES_NO_OPTION);
        if(confirma == JOptionPane.YES_OPTION){
            dao.excluir(jcodaparelho.getText());
            JOptionPane.showMessageDialog(null, "Excluído com Sucesso");
            limpar();
        }else{
            jcodaparelho.requestFocus();
        }
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jobservacao = new javax.swing.JTextArea();
        jLabel15 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jvalor = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jmenu = new javax.swing.JButton();
        jcodaparelho = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtabela = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jcliente = new javax.swing.JTextField();
        jeditar = new javax.swing.JButton();
        jexcluir = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jmaquiagem = new javax.swing.JTextField();
        jdataAgendamento = new javax.swing.JFormattedTextField();
        jhora = new javax.swing.JFormattedTextField();
        jdataConsulta = new javax.swing.JFormattedTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Consultar Agendamento");
        setResizable(false);
        addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                formInputMethodTextChanged(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        jButton3.setText("Consultar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel11.setText("Data Agendamento");

        jLabel12.setText("Observação");

        jobservacao.setColumns(20);
        jobservacao.setRows(5);
        jobservacao.setEnabled(false);
        jScrollPane6.setViewportView(jobservacao);

        jLabel15.setText("Hora");

        jLabel13.setText("Valor");

        jvalor.setEnabled(false);

        jLabel14.setText("Proprietário");

        jmenu.setText("Menu");
        jmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmenuActionPerformed(evt);
            }
        });

        jtabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Código", "Data Agendamento", "Hora", "Observação", "Valor", "Maquiagem", "Cliente"
            }
        ));
        jtabela.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtabelaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jtabela);

        jLabel1.setText("Cliente");

        jcliente.setEditable(false);
        jcliente.setBackground(new java.awt.Color(255, 255, 255));

        jeditar.setText("Editar");
        jeditar.setEnabled(false);
        jeditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jeditarActionPerformed(evt);
            }
        });

        jexcluir.setText("Excluir");
        jexcluir.setEnabled(false);
        jexcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jexcluirActionPerformed(evt);
            }
        });

        jLabel2.setText("Maquiagem");

        try {
            jdataAgendamento.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        try {
            jhora.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##:##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        try {
            jdataConsulta.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addComponent(jLabel14))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(348, 348, 348)
                        .addComponent(jmenu, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(95, 95, 95)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel15)
                            .addComponent(jLabel11)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel12)
                            .addComponent(jLabel13))
                        .addGap(35, 35, 35)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 371, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jdataAgendamento, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(155, 155, 155)
                                .addComponent(jcodaparelho, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jvalor, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jcliente, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 219, Short.MAX_VALUE)
                                .addComponent(jmaquiagem, javax.swing.GroupLayout.Alignment.LEADING))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jhora, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(168, 168, 168)
                                .addComponent(jeditar)
                                .addGap(18, 18, 18)
                                .addComponent(jexcluir))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jdataConsulta, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton3))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 806, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton3)
                    .addComponent(jdataConsulta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(jcodaparelho, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jdataAgendamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(jhora, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jcliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jmaquiagem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addGap(33, 33, 33)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jvalor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(58, 58, 58)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jeditar)
                            .addComponent(jexcluir))))
                .addGap(2690, 2690, 2690)
                .addComponent(jLabel14)
                .addGap(56, 56, 56)
                .addComponent(jmenu)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 826, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 516, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(105, 105, 105))
        );

        setSize(new java.awt.Dimension(842, 549));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jmenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmenuActionPerformed
        new Menu().setVisible(true);
        this.dispose();// TODO add your handling code here:
    }//GEN-LAST:event_jmenuActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
      consultar();     
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jtabelaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtabelaMouseClicked
        DefaultTableModel model = (DefaultTableModel) jtabela.getModel();
        int achou = jtabela.getSelectedRow();
        jcodaparelho.setText(model.getValueAt(achou, 0).toString());
        jdataAgendamento.setText(model.getValueAt(achou, 1).toString());
        jhora.setText(model.getValueAt(achou, 2).toString());
        jobservacao.setText(model.getValueAt(achou, 3).toString());
        jvalor.setText(model.getValueAt(achou, 4).toString().replace('.',','));
        jmaquiagem.setText(model.getValueAt(achou, 5).toString());
        jcliente.setText(model.getValueAt(achou, 6).toString());
        // TODO add your handling code here:
    }//GEN-LAST:event_jtabelaMouseClicked

    private void jeditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jeditarActionPerformed
    editar();    // TODO add your handling code here:
    }//GEN-LAST:event_jeditarActionPerformed

    private void jexcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jexcluirActionPerformed
    excluir();        // TODO add your handling code here:
    }//GEN-LAST:event_jexcluirActionPerformed

    private void formInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_formInputMethodTextChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_formInputMethodTextChanged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ConsulAgendamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ConsulAgendamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ConsulAgendamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ConsulAgendamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ConsulAgendamento().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTextField jcliente;
    private javax.swing.JLabel jcodaparelho;
    private javax.swing.JFormattedTextField jdataAgendamento;
    private javax.swing.JFormattedTextField jdataConsulta;
    private javax.swing.JButton jeditar;
    private javax.swing.JButton jexcluir;
    private javax.swing.JFormattedTextField jhora;
    private javax.swing.JTextField jmaquiagem;
    private javax.swing.JButton jmenu;
    private javax.swing.JTextArea jobservacao;
    private javax.swing.JTable jtabela;
    private javax.swing.JTextField jvalor;
    // End of variables declaration//GEN-END:variables

    
}
