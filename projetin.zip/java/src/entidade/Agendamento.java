
package entidade;


public class Agendamento {


    /**
     * @return the idAgendamento
     */
    public int getIdAgendamento() {
        return idAgendamento;
    }

    /**
     * @param idAgendamento the idAgendamento to set
     */
    public void setIdAgendamento(int idAgendamento) {
        this.idAgendamento = idAgendamento;
    }

    /**
     * @return the dataAgendamento
     */
    public String getDataAgendamento() {
        return dataAgendamento;
    }

    /**
     * @param dataAgendamento the dataAgendamento to set
     */
    public void setDataAgendamento(String dataAgendamento) {
        this.dataAgendamento = dataAgendamento;
    }

    /**
     * @return the hora
     */
    public String getHora() {
        return hora;
    }

    /**
     * @param hora the hora to set
     */
    public void setHora(String hora) {
        this.hora = hora;
    }

    /**
     * @return the observacao
     */
    public String getObservacao() {
        return observacao;
    }

    /**
     * @param observacao the observacao to set
     */
    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    /**
     * @return the valor
     */
    public double getValor() {
        return valor;
    }

    /**
     * @param valor the valor to set
     */
    public void setValor(double valor) {
        this.valor = valor;
    }

    /**
     * @return the maquiagem
     */
    public Maquiagem getMaquiagem() {
        return maquiagem;
    }

    /**
     * @param maquiagem the maquiagem to set
     */
    public void setMaquiagem(Maquiagem maquiagem) {
        this.maquiagem = maquiagem;
    }

    /**
     * @return the cliente
     */
    public Cliente getCliente() {
        return cliente;
    }

    /**
     * @param cliente the cliente to set
     */
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

   public int idAgendamento;
   public String dataAgendamento;
   public String hora;
   public String observacao;
   public double valor;
   public Maquiagem maquiagem;
   public Cliente cliente;

           public Agendamento(){
        
    }
 public Agendamento(int idAgendamento, String dataAgendamento,String hora,
             String observacao,Double valor, Cliente cliente, Maquiagem maquiagem){
        this.idAgendamento = idAgendamento;
        this.dataAgendamento= dataAgendamento;
        this.hora = hora;
        this.observacao = observacao;
        this.valor = valor;
        this.maquiagem = maquiagem;
        this.cliente=cliente;
        
    }
   
}