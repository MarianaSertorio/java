package dao;

import java.sql.*;
import conexao.Conexao;
import entidade.Cliente;
import javax.swing.JOptionPane;

public class ClienteDao {
    Connection conexao = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;
    
    public ClienteDao(){
        this.conexao = Conexao.conexao();
    }
 public void adicionar(Cliente cliente){
        String sql = "insert into cliente (nomeCliente,"
                + "telefoneCliente,enderecoCliente,emailCliente,dataNascimentoCliente,"
                + "cpfCliente) values"
                + "(?,?,?,?,?,?)";
        try{
            stmt = conexao.prepareStatement(sql);
            stmt.setString(1, cliente.getNomeCliente());          
            stmt.setString(2, cliente.getTelefoneCliente());
            stmt.setString(3, cliente.getEnderecoCliente());
            stmt.setString(4, cliente.getEmailCliente());
            stmt.setString(5, cliente.getDataNascimentoCliente());            
            stmt.setString(6, cliente.getCpfCliente());
            stmt.executeUpdate();
           
           
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Erro no banco"+
                    e.getMessage());
        }
    }
    
    public Cliente consultar(String cpfCliente){
        try{
           Cliente cliente = new Cliente();
           
           stmt = conexao.prepareStatement
        ("select * from cliente where cpfCliente =  ?");
           stmt.setString(1, cpfCliente);
           rs = stmt.executeQuery();
           if(rs.next()){
               cliente.setIdCliente(rs.getInt("idCliente"));
               cliente.setCpfCliente(rs.getString("cpfCliente"));
               cliente.setNomeCliente(rs.getString("nomeCliente"));
               cliente.setTelefoneCliente(rs.getString("telefoneCliente"));
               cliente.setEmailCliente(rs.getString("emailCliente"));
               cliente.setDataNascimentoCliente(rs.getString("dataNascimentoCliente"));
               cliente.setEnderecoCliente(rs.getString("enderecoCliente"));
               return cliente;
           }else{
               return null;
           }
        }catch(Exception e){
           return null;
        }
    }
    
    
    public void atualizar(Cliente cliente){
        String sql = "update cliente set nomeCliente=?,"
                + "telefoneCliente=?,emailCliente=?,dataNascimentoCliente=?,enderecoCliente=?,"
                + " where cpfCliente = ?";
        try{
            stmt = conexao.prepareStatement(sql);
            stmt.setString(6, cliente.getCpfCliente());
            stmt.setString(1, cliente.getNomeCliente());
            stmt.setString(2, cliente.getTelefoneCliente());            
            stmt.setString(3, cliente.getEmailCliente());
            stmt.setString(4, cliente.getDataNascimentoCliente());
            stmt.setString(5, cliente.getEnderecoCliente());
            stmt.executeUpdate();
            
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Erro no banco"+ 
                    e.getMessage());
        }
    }
    
    public boolean excluir(String cpfCliente){
        try{
            stmt = conexao.prepareStatement
                ("delete from cliente where cpfCliente = ?");
            stmt.setString(1, cpfCliente);
            stmt.executeUpdate();
            return true;
        }catch(Exception e){
            return false;
        }
    }
}

