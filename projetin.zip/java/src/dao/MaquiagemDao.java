package dao;

import java.sql.*;
import conexao.Conexao;
import entidade.Maquiagem;
import javax.swing.JOptionPane;

public class MaquiagemDao {
    Connection conexao = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;
    
    public MaquiagemDao(){
        this.conexao = Conexao.conexao();
    }
    public void adicionar(Maquiagem maquiagem){
        String sql = "insert into maquiagem (nomeMaquiagem,"
                + "descricao,"
                + "valor) values"
                + "(?,?,?)";
        try{
            stmt = conexao.prepareStatement(sql);
            stmt.setString(1, maquiagem.getNomeMaquiagem());
            stmt.setString(2, maquiagem.getDescricao());
            stmt.setDouble(3, maquiagem.getValor());

            stmt.executeUpdate();
            
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Erro no banco"+ 
                    e.getMessage());
        }
    }
    
    public Maquiagem consultar(String nomeMaquiagem){
        try{
           Maquiagem maquiagem = new Maquiagem();
           
           stmt = conexao.prepareStatement
        ("select * from maquiagem where nomeMaquiagem =  ?");
           stmt.setString(1, nomeMaquiagem);
           rs = stmt.executeQuery();
           if(rs.next()){
               maquiagem.setIdMaquiagem(rs.getInt("idMaquiagem"));
               maquiagem.setNomeMaquiagem(rs.getString("nomeMaquiagem"));
               maquiagem.setDescricao(rs.getString("descricao"));
               maquiagem.setValor(rs.getDouble("valor"));

               return maquiagem;
           }else{
               return null;
           }
        }catch(Exception e){
           return null;
        }
    }
    
    
    public void atualizar(Maquiagem maquiagem){
        String sql = "update maquiagem set Descricao=?,"
                + "valor=?,"
                + " where nomeMaquiagem = ?";
        try{
            stmt = conexao.prepareStatement(sql);
            stmt.setString(3, maquiagem.getNomeMaquiagem());
            stmt.setString(1, maquiagem.getDescricao());
            stmt.setDouble(2, maquiagem.getValor());            

            stmt.executeUpdate();
            
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Erro no banco"+ 
                    e.getMessage());
        }
    }
    
    public boolean excluir(String nomeMaquiagem){
        try{
            stmt = conexao.prepareStatement
                ("delete from maquiagem where nomeMaquiagem = ?");
            stmt.setString(1, nomeMaquiagem);
            stmt.executeUpdate();
            return true;
        }catch(Exception e){
            return false;
        }
    }
}

